﻿using System;

//Пользователь вводит с клавиатуры два числа. Первое 
//число — это значение, второе число процент, который 
//необходимо посчитать. Например, мы ввели с клавиатуры 
//90 и 10. Требуется вывести на экран 10 процентов от 90. 
//Результат: 9.
class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Введите число: ");
        double number = double.Parse(Console.ReadLine());

        Console.WriteLine("Введите процент: ");
        double procent = double.Parse(Console.ReadLine());

        double result = (number * procent) / 100;

        Console.WriteLine($"Результат: {result}");
    }
}
